package com.example.appointment_with_a_doctor.exceptions;

public class DoctorUpdateException extends Exception{
    public DoctorUpdateException(String message) {
        super(message);
    }
}
