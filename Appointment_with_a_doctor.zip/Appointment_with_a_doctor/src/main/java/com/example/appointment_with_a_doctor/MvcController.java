package com.example.appointment_with_a_doctor;

import com.example.appointment_with_a_doctor.db.DoctorRepository;
import com.example.appointment_with_a_doctor.db.RecordRepository;
import com.example.appointment_with_a_doctor.exceptions.DoctorUpdateException;
import com.example.appointment_with_a_doctor.exceptions.IncorrectData;
import com.example.appointment_with_a_doctor.exceptions.IncorrentDataForAuthorization;
import com.fasterxml.jackson.databind.util.JSONPObject;
import org.apache.tomcat.util.json.JSONParser;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletResponse;
import java.util.Iterator;
import java.util.List;

@Controller
@RequestMapping("/")
public class MvcController {

    @Autowired
    private LogicService logicService;

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private RecordRepository recordRepository;

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String getLogin(@ModelAttribute("err") String err, Model model) {
        model.addAttribute("err", err);
        return "login";
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String getLogin(@RequestParam("email") String email, @RequestParam("password") String password, Model model, RedirectAttributes redirectAttributes) {
        try {
            User user = logicService.login(email, password);
            if (user.getRole().equals(Role.DOCTOR)) {
                redirectAttributes.addFlashAttribute("id", user.getId());
                return "redirect:/doctor-profile";
            }
            if (user.getRole().equals(Role.PATIENT)) {
                redirectAttributes.addFlashAttribute("id", user.getId());
                return "redirect:/user-recording";
            }
        } catch (IncorrentDataForAuthorization e) {
            redirectAttributes.addFlashAttribute("err", e.getMessage());
            return "redirect:/login";
        }
        redirectAttributes.addFlashAttribute("err", "Неизвестная ошибка при авторизации!");
        return "redirect:/login";
    }

    @RequestMapping(value = "/doctor-profile", method = RequestMethod.GET)
    public String getDoctorProfile(@ModelAttribute("id") Long id, @ModelAttribute("err") Object err, Model model) throws IncorrectData {
        Doctor doctor = doctorRepository.findDoctorById(id);
        if (doctor != null) {
            model.addAttribute("id", doctor.getId());
            model.addAttribute("lastname", doctor.getLastName());
            model.addAttribute("firstname", doctor.getFirstName());
            model.addAttribute("secondname", doctor.getSecondName());
            model.addAttribute("specialization", doctor.getSpecialization());
            model.addAttribute("specialisations", Specializations.values());
            model.addAttribute("monday", doctor.getWorkingDays()[0]);
            model.addAttribute("tuesday", doctor.getWorkingDays()[1]);
            model.addAttribute("wednesday", doctor.getWorkingDays()[2]);
            model.addAttribute("thursday", doctor.getWorkingDays()[3]);
            model.addAttribute("friday", doctor.getWorkingDays()[4]);
            model.addAttribute("saturday", doctor.getWorkingDays()[5]);
            model.addAttribute("sunday", doctor.getWorkingDays()[6]);
            model.addAttribute("work_since", doctor.getWorkingHours()[0]);
            model.addAttribute("work_to", doctor.getWorkingHours()[1]);
            model.addAttribute("photoImagePath", doctor.getPhotosImagePath());
            model.addAttribute("err", err);
            return "doctor-profile";
        } else {
            throw new IncorrectData("Некорректный doctorId: " + id);
        }
    }

    @RequestMapping(value = "/doctor-profile", method = RequestMethod.POST)
    public String getDoctorProfile(RedirectAttributes redirectAttributes,
                                   @RequestParam(name = "id", defaultValue = "") Long id, HttpServletResponse httpServletResponse,
                                   @RequestParam(name = "lastname", defaultValue = "") String lastname,
                                   @RequestParam(name = "firstname", defaultValue = "") String firstname,
                                   @RequestParam(name = "secondname", defaultValue = "") String secondname,
                                   @RequestParam(name = "specialization", defaultValue = "") String specialization,
                                   @RequestParam(name = "monday", defaultValue = "false") Boolean monday,
                                   @RequestParam(name = "tuesday", defaultValue = "false") Boolean tuesday,
                                   @RequestParam(name = "wednesday", defaultValue = "false") Boolean wednesday,
                                   @RequestParam(name = "thursday", defaultValue = "false") Boolean thursday,
                                   @RequestParam(name = "friday", defaultValue = "false") Boolean friday,
                                   @RequestParam(name = "saturday", defaultValue = "false") Boolean saturday,
                                   @RequestParam(name = "sunday", defaultValue = "false") Boolean sunday,
                                   @RequestParam(name = "work_since", defaultValue = "") String work_since,
                                   @RequestParam(name = "work_to", defaultValue = "") String work_to,
                                   @RequestParam(name = "photo") MultipartFile multipartFile) {

        Doctor doctor = new Doctor(id, lastname, firstname, secondname, specialization,
                new boolean[]{monday, tuesday, wednesday, thursday, friday, saturday, sunday},
                new String[]{work_since, work_to}, StringUtils.cleanPath(multipartFile.getOriginalFilename()));
        try {
            logicService.updateDoctor(doctor, multipartFile);
        } catch (DoctorUpdateException e) {
            redirectAttributes.addFlashAttribute("err", e.getMessage());
        }
        redirectAttributes.addFlashAttribute("id", id);
        return "redirect:/doctor-profile";
    }

    @RequestMapping(value = "/user-recording", method = RequestMethod.GET)
    public String getUserRecordingStart(@ModelAttribute("id") Long id, Model model) {
        model.addAttribute("id", id);
        model.addAttribute("specializations", Specializations.values());
        return "user-recording";
    }

    @GetMapping("/doctorsBySpecialization")
    public String getDoctorsBySpecialization(@RequestParam("specialization") String specializationStr) {
        Specializations specialization = Specializations.valueOf(specializationStr);
        List<Doctor> doctors = doctorRepository.findDoctorsBySpecialization(specialization);
        Iterator<Doctor> iterator = doctors.iterator();
        JSONObject jsonObject = new JSONObject();
        for (int i = 0; i < doctors.size(); i++) {
            Doctor doctor = iterator.next();
            JSONObject jsonDoctor = new JSONObject();
            jsonDoctor.put("id", doctor.getId());
            jsonDoctor.put("firstName", doctor.getFirstName());
            jsonDoctor.put("secondName", doctor.getSecondName());
            jsonDoctor.put("lastName", doctor.getLastName());
            jsonObject.put(i+"", jsonDoctor);
        }
        return jsonObject.toString();
    }

    @GetMapping("/doctorsTimeInDate")
    public String getDoctorsFreeTime(@RequestParam("id") Long id, @RequestParam("date") String date){
        List<Record> records = recordRepository.findDoctorRecordByDate(id, date);
        Doctor doctor = doctorRepository.findDoctorById(id);
        JSONObject jsonObject = new JSONObject();
    }
}
