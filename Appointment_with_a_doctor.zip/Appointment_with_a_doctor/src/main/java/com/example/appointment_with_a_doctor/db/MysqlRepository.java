package com.example.appointment_with_a_doctor.db;

import com.example.appointment_with_a_doctor.Doctor;
import com.example.appointment_with_a_doctor.Record;
import com.example.appointment_with_a_doctor.Patient;
import com.example.appointment_with_a_doctor.Role;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.sql.*;
import java.util.Arrays;

@Service
public class MysqlRepository implements DoctorRepository, UsersRepository, RecordRepository {
    //    private final static String url = "jdbc:mysql://localhost:3306/hospital_base";
//    private final static String user = "root";
//    private final static String password = "root";
    private final static String url = "jdbc:postgresql://localhost:8999/studs";
    private final static String user = "s309681";
    private final static String password = "yvr557";

    @PostConstruct
    public void createDoctorsTable() {
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS DOCTOR_ACCOUNTS " +
                    "(id serial not null, " +
                    "last_name VARCHAR(45) default ''," +
                    "first_name VARCHAR(45) default ''," +
                    "second_name VARCHAR(45) default ''," +
                    "specialization VARCHAR(45) default ''," +
                    "working_days VARCHAR(45) default 'false|false|false|false|false|false|false'," +
                    "working_hours VARCHAR(45) default '0|0'," +
                    "photo VARCHAR(255) default ''," +
                    "email VARCHAR(45) default ''," +
                    "password VARCHAR(45) default ''" +
                    ")";
            statement.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @PostConstruct
    public void createUsersTable() {
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS USER_ACCOUNTS " +
                    "(id serial not null, " +
                    "email VARCHAR(45) default ''," +
                    "password VARCHAR(45) default ''" +
                    ");";
            statement.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @PostConstruct
    public void recorders() {
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS RECORDS" +
                    " (id serial not null, " +
                    "doctorEmail VARCHAR(45) default ''," +
                    "userEmail VARCHAR(45) default ''," +
                    "recordDate VARCHAR(45) default ''," +
                    "recordTime VARCHAR(45) default ''" +
                    ");";
            statement.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Doctor findDoctorById(Long id) {
        Doctor doctor = null;
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("select * from" +
                    " DOCTOR_ACCOUNTS where id='"
                    + id + "';");
            if (resultSet.next()) {
                doctor = new Doctor();
                doctor.setRole(Role.DOCTOR);
                doctor.setId(new Long(resultSet.getString("id")));
                doctor.setEmail(resultSet.getString("email"));
                doctor.setPassword(resultSet.getString("password"));
                doctor.setFirstName(resultSet.getString("first_name"));
                doctor.setSecondName(resultSet.getString("second_name"));
                doctor.setLastName(resultSet.getString("last_name"));
                doctor.setSpecialization(resultSet.getString("specialization"));
                String[] workingDays = resultSet.getString("working_days").split("\\|");
                boolean[] days = new boolean[7];
                for (int i = 0; i < days.length; i++) {
                    days[i] = Boolean.valueOf(workingDays[i]);
                }
                doctor.setWorkingDays(days);
                doctor.setWorkingHours(resultSet.getString("working_hours").split("\\|"));
                doctor.setPhoto(resultSet.getString("photo"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return doctor;
    }

    @Override
    public Doctor saveDoctor(Doctor doctor) {
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {

            String workingDays = "";
            for(boolean workingDay : doctor.getWorkingDays()){
                workingDays += "|" + workingDay;
            }
            workingDays = workingDays.substring(1);

            String workingHours = "";
            for(String workingHour : doctor.getWorkingHours()){
                workingHours += "|" + workingHour;
            }
            workingHours = workingHours.substring(1);

            if(doctor.getPhoto().equals("")){
                doctor.setPhoto(findDoctorById(doctor.getId()).getPhoto());
            }
            String str = "UPDATE DOCTOR_ACCOUNTS SET last_name" +
                    " = '" + doctor.getLastName() + "', first_name = '"
                    + doctor.getFirstName() + "', second_name = '"
                    + doctor.getSecondName() + "', specialization = '"
                    + doctor.getSpecialization() + "', working_days = '"
                    + workingDays + "', working_hours = '"
                    + workingHours + "', photo = '"
                    + doctor.getPhoto() + "' WHERE (id = '"
                    + doctor.getId() + "');";
            statement.executeUpdate(str);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return doctor;
    }


    @Override
    public Doctor findDoctorByEmail(String email) {

        Doctor doctor = null;
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("select * from" +
                    " DOCTOR_ACCOUNTS where email='"
                    + email + "';");
            if (resultSet.next()) {
                doctor = new Doctor();
                doctor.setRole(Role.DOCTOR);
                doctor.setId(new Long(resultSet.getString("id")));
                doctor.setEmail(resultSet.getString("email"));
                doctor.setPassword(resultSet.getString("password"));
                doctor.setFirstName(resultSet.getString("first_name"));
                doctor.setSecondName(resultSet.getString("second_name"));
                doctor.setLastName(resultSet.getString("last_name"));
                doctor.setSpecialization(resultSet.getString("specialization"));
                String[] workingDays = resultSet.getString("working_days").split("\\|");
                boolean[] days = new boolean[7];
                for (int i = 0; i < days.length; i++) {
                    days[i] = Boolean.valueOf(workingDays[i]);
                }
                doctor.setWorkingDays(days);
                doctor.setWorkingHours(resultSet.getString("working_hours").split("\\|"));
                doctor.setPhoto(resultSet.getString("photo"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return doctor;
    }

    @Override
    public Patient findPatientById(Long id) {
        Patient patient = null;
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("select * from" +
                    " USER_ACCOUNTS where id='"
                    + id + "';");
            if (resultSet.next()) {
                patient = new Patient();
                patient.setRole(Role.PATIENT);
                patient.setId(new Long(resultSet.getString("id")));
                patient.setEmail(resultSet.getString("email"));
                patient.setPassword(resultSet.getString("password"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return patient;
    }

    @Override
    public Patient savePatient(Patient patient) {
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            String str = "INSERT INTO USER_ACCOUNTS (email, password) VALUES ('" + patient.getEmail() + "', '" + patient.getPassword() + "');";
            statement.executeUpdate(str);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        patient.setRole(Role.PATIENT);
        return patient;
    }

    @Override
    public Patient findPatientByEmail(String email) {
        Patient patient = null;
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("select * from" +
                    " USER_ACCOUNTS where email='"
                    + email + "';");
            if (resultSet.next()) {
                patient = new Patient();
                patient.setRole(Role.PATIENT);
                patient.setId(new Long(resultSet.getString("id")));
                patient.setEmail(resultSet.getString("email"));
                patient.setPassword(resultSet.getString("password"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return patient;
    }


//    @Override
//    public Record findRecordByDoctorAndTime(String doctorEmail, String day, String time) {
//        Record record = null;
//        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
//             Statement statement = connection.createStatement()) {
//            ResultSet resultSet = statement.executeQuery("select * from" +
//                    " RECORDS where doctorEmail='"
//                    + doctorEmail + "', recordDate='" + day + "', recordTime='" + time + "';");
//            if (resultSet.next()) {
//                record = new Record();
//                record.setDoctorEmail(resultSet.getString("doctorEmail"));
//                record.setDay(resultSet.getString("recordDate"));
//                record.setTime(resultSet.getString("recordTime"));
//                record.setUserEmail(resultSet.getString("userEmail"));
//            }
//        } catch (SQLException throwables) {
//            throwables.printStackTrace();
//        }
//        return record;
//    }

    @Override
    public Record findRecordByUserId(Long userId) {
        return null;
    }

    @Override
    public Record findRecordByDoctorId(Long doctorId) {
        return null;
    }

    @Override
    public Record saveRecord(Record record/*tring doctorEmail, String userEmail, String day, String time*/) {
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            String str = "INSERT INTO RECORDS (doctorEmail, userEmail, recordDate, recordTime) " +
                    "VALUES ('" + record.getDoctorEmail() + "', '" + record.getUserEmail() + "'," +
                    "'" + record.getDay() + "', '" + record.getTime() + "');";
            statement.executeUpdate(str);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        return record;
    }
}
