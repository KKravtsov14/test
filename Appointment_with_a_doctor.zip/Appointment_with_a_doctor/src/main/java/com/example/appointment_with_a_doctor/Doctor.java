package com.example.appointment_with_a_doctor;

import java.beans.Transient;

public class Doctor implements User{

    private Long id;
    private String email;
    private String password;
    private String lastName;
    private String firstName;
    private String secondName;
    private String specialization;
    private boolean[] workingDays;
    private String[] workingHours;
    private String photo;
    private Role role;


    public Doctor() {
    }

    public Doctor(Long id, String lastName, String firstName, String secondName, String specialization, boolean[] workingDays, String[] workingHours, String photo) {
        this.id = id;
        this.lastName = lastName;
        this.firstName = firstName;
        this.secondName = secondName;
        this.specialization = specialization;
        this.workingDays = workingDays;
        this.workingHours = workingHours;
        this.photo = photo;
    }

    @Override
    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public String getSecondName() {
        return this.secondName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public String getEmail() {return this.email;}

    public String getPassword() {
        return this.password;
    }

    public String getSpecialization() {
        return this.specialization;
    }

    public String getPhoto() {
        return this.photo;
    }


    public void setEmail(String email) {
        this.email = email;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public boolean[] getWorkingDays() {
        return workingDays;
    }

    public void setWorkingDays(boolean[] workingDays) {
        this.workingDays = workingDays;
    }

    public String[] getWorkingHours() {
        return workingHours;
    }

    public void setWorkingHours(String[] workingHours) {
        this.workingHours = workingHours;
    }

    @Override
    public String toString() {
        return this.firstName + " "+ this.lastName;
    }

    @Transient
    public String getPhotosImagePath() {
        //if (photo == null || email == null) return null;
        if (photo.equals("")){
            return "/user-photos/profile_picture.jpg";
        }

        return "/user-photos/" + id + "/" + photo;
    }

}

