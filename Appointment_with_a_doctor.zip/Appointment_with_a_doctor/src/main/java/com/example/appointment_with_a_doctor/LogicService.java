package com.example.appointment_with_a_doctor;

import com.example.appointment_with_a_doctor.configs.FileUploadUtil;
import com.example.appointment_with_a_doctor.db.DoctorRepository;
import com.example.appointment_with_a_doctor.db.UsersRepository;
import com.example.appointment_with_a_doctor.exceptions.DoctorUpdateException;
import com.example.appointment_with_a_doctor.exceptions.IncorrentDataForAuthorization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
public class LogicService {

    @Autowired
    private DoctorRepository doctorRepository;
    @Autowired
    private UsersRepository usersRepository;

    public User login(String email, String password) throws IncorrentDataForAuthorization {
        Doctor doctor = doctorRepository.findDoctorByEmail(email);
        Patient patient = usersRepository.findPatientByEmail(email);
        if (doctor != null) {
            if (doctor.getPassword().equals(password)) {
                return doctor;
            } else {
                throw new IncorrentDataForAuthorization("Неверный пароль для доктора!");
            }
        }
        if (patient != null) {
            if(patient.getPassword().equals(password)) {
                return patient;
            }else {
                throw new IncorrentDataForAuthorization("Неверный пароль для пользователя!");
            }
        }
        if(!email.equals("") && !password.equals("")) {
            Patient patient1 = usersRepository.savePatient(new Patient(email, password));
            return patient1;
        }else {
            throw new IncorrentDataForAuthorization("Оба поля должны быть заполнены!");
        }
    }

    public void updateDoctor(Doctor doctor, MultipartFile multipartFile) throws DoctorUpdateException {
        try {
            Doctor oldDoctor = doctorRepository.findDoctorByEmail(doctor.getEmail());
            String photoFileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
            if (photoFileName.equals("") && oldDoctor != null) {
                photoFileName = oldDoctor.getPhoto();
            }
            doctor = doctorRepository.saveDoctor(doctor);
            if (!multipartFile.isEmpty()) {
                String uploadDir = "user-photos/" + doctor.getId();
                FileUploadUtil.saveFile(uploadDir, photoFileName, multipartFile);
            }
        } catch (Exception e) {
            throw new DoctorUpdateException(e.getMessage());
        }
    }
}
