package com.example.appointment_with_a_doctor.db;

import com.example.appointment_with_a_doctor.Patient;

public interface UsersRepository {
    Patient findPatientById(Long id);

    Patient savePatient(Patient patient);

    Patient findPatientByEmail(String email);
}
