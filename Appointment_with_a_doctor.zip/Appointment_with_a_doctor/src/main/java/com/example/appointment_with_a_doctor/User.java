package com.example.appointment_with_a_doctor;

public interface User {
    Role getRole();
    Long getId();
}
