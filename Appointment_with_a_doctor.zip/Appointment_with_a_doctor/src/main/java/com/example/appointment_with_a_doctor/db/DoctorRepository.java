package com.example.appointment_with_a_doctor.db;


import com.example.appointment_with_a_doctor.Doctor;
import com.example.appointment_with_a_doctor.Specializations;

import java.util.List;

public interface DoctorRepository {

    Doctor findDoctorById(Long id);

    Doctor saveDoctor(Doctor doctor);

    Doctor findDoctorByEmail(String email);

    List<Doctor> findDoctorsBySpecialization(Specializations specializations);
}
