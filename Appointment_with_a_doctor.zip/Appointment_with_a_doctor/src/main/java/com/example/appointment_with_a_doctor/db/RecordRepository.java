package com.example.appointment_with_a_doctor.db;

import com.example.appointment_with_a_doctor.Record;

import java.util.List;

public interface RecordRepository {
    Record findRecordByUserId(Long userId);
    Record findRecordByDoctorId(Long doctorId);
    Record saveRecord(Record record);
    List<Record> findDoctorRecordByDate(Long id, String date);
    Record findPatientRecordByDate(Long id, String date);
}
