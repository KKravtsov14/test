var specializationChecker = () => {
    $.get();
}