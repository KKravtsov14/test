package com.example.appointment_with_a_doctor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointmentWithADoctorApplicationTests {

    @Test
    void contextLoads() {
    }

}
