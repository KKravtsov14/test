package com.example.appointment_with_a_doctor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppointmentWithADoctorApplication {

    public static void main(String[] args) {
        SpringApplication.run(AppointmentWithADoctorApplication.class, args);
    }

}
