package com.example.appointment_with_a_doctor.exceptions;

public class IncorrentDataForAuthorization extends Exception{
    public IncorrentDataForAuthorization(String message){
        super(message);
    }
}
