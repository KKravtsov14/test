package com.example.appointment_with_a_doctor;

public class Record {
    private String doctorEmail;
    private String userEmail;
    private String day;
    private String time;

    public Record() {
    }

    public Record(String doctorEmail, String userEmail, String day, String time) {
        this.doctorEmail = doctorEmail;
        this.userEmail = userEmail;
        this.day = day;
        this.time = time;
    }

    public String getDoctorEmail() {
        return doctorEmail;
    }

    public void setDoctorEmail(String doctorEmail) {
        this.doctorEmail = doctorEmail;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
