package com.example.appointment_with_a_doctor.db;

import com.example.appointment_with_a_doctor.Doctor;
import com.example.appointment_with_a_doctor.Record;
import com.example.appointment_with_a_doctor.User;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.sql.*;

@Service
public class MysqlRepository implements DoctorRepository, UsersRepository, RecordRepository {

    private final static String url = "jdbc:mysql://localhost:3306/hospital_base";
    private final static String user = "root";
    private final static String password = "root";

    @PostConstruct
    public void createDoctorsTable() {
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS DOCTOR_ACCOUNTS" +
                    " (last_name VARCHAR(45) default ''," +
                    "first_name VARCHAR(45) default ''," +
                    "second_name VARCHAR(45) default ''," +
                    "specialization VARCHAR(45) default ''," +
                    "working_days VARCHAR(45) default 'false|false|false|false|false|false|false'," +
                    "working_hours VARCHAR(45) default '0|0'," +
                    "photo VARCHAR(255) default ''," +
                    "email VARCHAR(45) default ''," +
                    "password VARCHAR(45) default ''" +
                    ")";
            statement.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @PostConstruct
    public void createUsersTable() {
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS USER_ACCOUNTS" +
                    " (email VARCHAR(45) default ''," +
                    "password VARCHAR(45) default ''" +
                    ");";
            statement.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @PostConstruct
    public void recorders() {
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS RECORDS" +
                    " (doctorEmail VARCHAR(45) default ''," +
                    "userEmail VARCHAR(45) default ''," +
                    "recordDate VARCHAR(45) default ''," +
                    "recordTime VARCHAR(45) default ''" +
                    ");";
            statement.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Doctor saveDoctor(Doctor doctor) {
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            String str = "UPDATE DOCTOR_ACCOUNTS SET last_name" +
                    " = '" + doctor.getLastName() + "', first_name = '"
                    + doctor.getFirstName() + "', second_name = '"
                    + doctor.getSecondName() + "', specialization = '"
                    + doctor.getSpecialization() + "', working_days = '"
                    + doctor.getWorkingDays() + "', working_hours = '"
                    + doctor.getWorkingHours() + "', photo = '"
                    + doctor.getPhoto() + "' WHERE (email = '"
                    + doctor.getEmail() + "');";
            System.out.println(str);
            statement.executeUpdate(str);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return doctor;
    }


    @Override
    public Doctor findDoctorByUsername(String email) {

        Doctor doctor = null;
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("select * from" +
                    " DOCTOR_ACCOUNTS where email='"
                    + email + "';");
            if (resultSet.next()) {
                doctor = new Doctor();
                doctor.setEmail(resultSet.getString("email"));
                doctor.setPassword(resultSet.getString("password"));
                doctor.setFirstName(resultSet.getString("first_name"));
                doctor.setSecondName(resultSet.getString("second_name"));
                doctor.setLastName(resultSet.getString("last_name"));
                doctor.setSpecialization(resultSet.getString("specialization"));
                doctor.setWorkingDays(resultSet.getString("working_days"));
                doctor.setWorkingHours(resultSet.getString("working_hours"));
                doctor.setPhoto(resultSet.getString("photo"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return doctor;
    }

    @Override
    public User saveUser(User user) {
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            String str = "INSERT INTO USER_ACCOUNTS (email, password) VALUES ('" + user.getEmail() + "', '" + user.getPassword() + "');";
            statement.executeUpdate(str);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        return user;
    }

    @Override
    public User findUserByUsername(String username) {
        User user = null;
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("select * from" +
                    " USER_ACCOUNTS where email='"
                    + username + "';");
            if (resultSet.next()) {
                user = new User();
                user.setEmail(resultSet.getString("email"));
                user.setPassword(resultSet.getString("password"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return user;
    }



    @Override
    public Record findRecordByDoctorAndTime(String doctorEmail, String day, String time) {
        Record record = null;
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("select * from" +
                    " RECORDS where doctorEmail='"
                    + doctorEmail + "', recordDate='"+day+"', recordTime='"+time+"';");
            if (resultSet.next()) {
                record = new Record();
                record.setDoctorEmail(resultSet.getString("doctorEmail"));
                record.setDay(resultSet.getString("recordDate"));
                record.setTime(resultSet.getString("recordTime"));
                record.setUserEmail(resultSet.getString("userEmail"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return record;
    }

    @Override
    public Record saveRecord(String doctorEmail, String userEmail, String day, String time) {
        Record record = new Record(doctorEmail, userEmail, day, time);
        try (Connection connection = DriverManager.getConnection(url, MysqlRepository.user, password);
             Statement statement = connection.createStatement()) {
            String str = "INSERT INTO RECORDS (doctorEmail, userEmail, recordDate, recordTime) " +
                    "VALUES ('" + record.getDoctorEmail() + "', '" + record.getUserEmail() + "'," +
                    "'"+record.getDay()+"', '"+record.getTime()+"');";
            statement.executeUpdate(str);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        return record;
    }
}
