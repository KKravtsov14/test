package com.example.appointment_with_a_doctor.db;

import com.example.appointment_with_a_doctor.User;

public interface UsersRepository {
//    Iterable<User> findAllUsers();

    User saveUser(User doctor);
//
//    User findUserById(Long id);
//
    User findUserByUsername(String username);
}
