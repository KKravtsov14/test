package com.example.appointment_with_a_doctor.db;

import com.example.appointment_with_a_doctor.Record;

public interface RecordRepository {
    Record findRecordByDoctorAndTime(String doctorEmail, String day, String time);
    Record saveRecord(String doctorEmail, String userEmail, String day, String time);
}
