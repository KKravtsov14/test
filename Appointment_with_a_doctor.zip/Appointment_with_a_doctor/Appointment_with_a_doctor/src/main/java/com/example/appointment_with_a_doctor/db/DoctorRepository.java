package com.example.appointment_with_a_doctor.db;


import com.example.appointment_with_a_doctor.Doctor;

public interface DoctorRepository {

    Doctor saveDoctor(Doctor doctor);

    Doctor findDoctorByUsername(String username);
}
