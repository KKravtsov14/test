package com.example.appointment_with_a_doctor.exceptions;

public class IncorrectData extends Exception{
}
